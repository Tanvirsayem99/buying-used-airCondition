const { createServer } = require("http");
const next = require("next");

const port = parseInt(process.env.PORT, 10) || 3000;
const hostname = "127.0.0.1";

const app = next({
    dev: false,
    hostname,
    port,
});

const handle = app.getRequestHandler();

app.prepare().then(() => {
    createServer(async (req, res) => {
        try {
            await handle(req, res);
        } catch (err) {
            console.error(err);
            res.statusCode = 500;
            res.end("Internal Server Error");
        }
    }).listen(port, hostname, () => {
        console.log(`> Ready on http://${hostname}:${port}`);
    });
});